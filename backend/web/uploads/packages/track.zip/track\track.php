<?php 
namespace frontend\modules\track;

/**
 * Description of module
 *
 * @author OneLab
 */
class track extends \yii\base\Module{
    /**
     * @inheritdoc
     */
    public $controllerNamespace = 'frontend\modules\track\controllers';

    /**
     * @inheritdoc
     */
    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
